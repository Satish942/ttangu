import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  templateUrl: 'book-details.component.html'
})

export class BookDetailsComponent {

}