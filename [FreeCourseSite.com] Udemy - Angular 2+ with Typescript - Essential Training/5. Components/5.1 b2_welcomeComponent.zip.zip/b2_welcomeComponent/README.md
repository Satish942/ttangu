** Make sure you are running Node.js Version 8.x **

1. Download the files

2. Navigate to the root folder location in your terminal.

3. Type 'npm install'. This installs the node-module dependencies defined in the package.json

4. Type 'npm start'. This launches the TypeScript compiler (tsc) to compile the typescript files into javascript and watches for changes. It also starts the lite-server and launches in the browser to run the application on port 3000.